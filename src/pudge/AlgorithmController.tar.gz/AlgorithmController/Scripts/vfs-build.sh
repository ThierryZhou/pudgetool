
#!/bin/bash
path=$1
mode=$2

if [ $mode neq 2 ]; then
    echo 
fi

if [ -d $path/VideoFaceAlg/jssjVFC/ ]; then
    sudo rm -rf $path/VideoFaceAlg/jssjVFC
fi
sudo mkdir -p $path/VideoFaceAlg/jssjVFC/
sudo unzip $path/third_part/VFC_ReleasePack.zip -d $path/VideoFaceAlg/
sudo chmod -R 755 $path/VideoFaceAlg/jssjVFC/
sudo cp -r $path/Scripts/create_link.sh  $path/Scripts/delete_link.sh $path/VideoFaceAlg/jssjVFC/bin/linux
sudo bash $path/VideoFaceAlg/jssjVFC/bin/linux/create_link.sh

if [ -d $path/dist/ ]; then
    sudo rm -rf $path/dist/
fi
cd $path/Lib/linux
./delete_link.sh
cd -
