sudo tar xvf ffmpeg-4.1.tar.gz2
cd third_part/ffmpeg-4.1
sudo git clone https://git.videolan.org/git/ffmpeg/nv-codec-headers.git
cd nv-codec-headers
sudo make&&make install
cd -
sudo ./configure --enable-shared --enable-cuda --enable-cuvid --enable-nvenc --enable-nonfree --enable-libnpp --extra-cflags=-I/usr/local/cuda/include --extra-ldflags=-L/usr/local/cuda/lib64
sudo make&&make install
cd -