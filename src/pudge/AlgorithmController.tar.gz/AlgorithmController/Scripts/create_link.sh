#!/bin/bash
path=`dirname $0`
ftype=`df -T ${path}|awk 'NR==2{print $2}'`
if [ "${ftype}" == "cifs" ] ; then
    echo "error: can't create link file in windows shared folders!"
    exit 0
fi
for file in `ls $path/*.so.*.*.*`
do
    file1=${file%.*}
    if [ ! -e ${file1} ]; then
        sudo ln -s $file $file1
        echo 'create link '${file1}
    fi

    file2=${file1%.*}
    if [ ! -e $file2 ]; then
        sudo ln -s $file1 $file2
        echo 'create link '${file2}
    fi

    file3=${file2%.*}
    if [ ! -e $file3 ]; then
        sudo ln -s $file2 $file3
        echo 'create link '${file3}
    fi
done