#!/bin/bash
find ./ -type l |xargs rm -rf {}