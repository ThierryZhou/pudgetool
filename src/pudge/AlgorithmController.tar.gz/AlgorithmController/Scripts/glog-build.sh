sudo tar xvf v0.3.5.tar.gz 
sudo mkdir glog-0.3.5/linux
cd glog-0.3.5/linux
sudo cmake ..
sudo make
sudo make install
cd -


