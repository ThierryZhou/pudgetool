﻿#ifndef __VSF_CODEC_DEFINE_H__
#define __VSF_CODEC_DEFINE_H__

#include "SystemCall.h"
#include "jssjBasicFunction.h"
#include "Utils/NvCodecUtils.h"
#include <glog/logging.h>
#include "nvcuvid.h"
#include <string.h>
#include <pthread.h>  
#include <sched.h>
#include <unistd.h>
#include <memory>
#include <iostream>

static int bindGPUDvice(int nDevIdx)
{
    return JSSJ_BF_SetGpuDevice(0, nDevIdx);
}

#endif