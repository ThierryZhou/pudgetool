/************************************************************************
Copyright(C),2000-2020,JSSJ Tech.Co.,Ltd.
FileName: jssjBasicFunction.h
Author: ������    Date: 2017-12-12
Description:

History:
<author>        <time>        <version>        <desc>
��������������2017-12-12     1.0.0        �������ļ�
************************************************************************/
#ifndef JSSJ_BASICFUNCTION_H
#define JSSJ_BASICFUNCTION_H
#include <stdlib.h>         // for size_t on linux
#pragma pack(push, 8)
typedef enum {
    BF_CPU_DEVICE = 0,
    BF_GPU_DEVICE = 1,
}JSDJ_BF_DeviceType;
typedef  enum {
    BF_IMG_GRAY = 0,
    BF_IMG_BGR = 1,            // channel first
    BF_IMG_RGB = 2,            // channel first
    BF_IMG_BGR2 = 3,        // width first
    BF_IMG_RGB2 = 4,        // width first
    BF_IMG_YUV422 = 5,
    BF_IMG_YUV420_I420 = 6,  // I420: YYYYYYYY UU VV
    BF_IMG_YUV420_YV12 = 7,  // YV12: YYYYYYYY VV UU
    BF_IMG_YUV420_NV12 = 8,  // NV12: YYYYYYYY UV UV
    BF_IMG_YUV420_NV21 = 9,  // NV21: YYYYYYYY VU VU
}JSDJ_BF_ImageFormat;
typedef struct JSDJ_BF_Point {
    float x;
    float y;
}JSDJ_BF_Point;
typedef struct JSDJ_BF_Image {
    unsigned char *image_data;
    int memory_size;
    int data_size;
    int width;
    int height;
    int batch;
    JSDJ_BF_ImageFormat image_format;  
    JSDJ_BF_DeviceType storage_format;      // data storage format
}JSDJ_BF_Image;
typedef struct JSDJ_BF_InitParam {    
    int max_buffer_size;
}JSDJ_BF_InitParam;
#pragma pack(pop)
#ifdef    __cplusplus
extern "C"
{
#endif
#ifdef _WIN32
    // Get valid cuda device number, by set the gpu_sm to find the device beyond it                                               
    int __stdcall JSSJ_BF_GetGpuDeviceNum(const float gpu_sm, int *gpu_device_num);
    // set GPU device for host thread, a default device will be set without calling
    int __stdcall JSSJ_BF_SetGpuDevice(const float gpu_sm, const int gpu_device_id);
    // set GPU device flags, If the current device has been set and that device has already been initialized then this call will fail
    // 0 for auto, 1 for actively spin, 2 for yield(mutil-card)
    int __stdcall JSSJ_BF_SetGpuDeviceFlags(unsigned int flags);
    // reset GPU device, Destroy all allocations and reset all state on the current device in the current process
    int __stdcall JSSJ_BF_RetGpuDevice();
    // register memory page-lock, it accelerate process functions in gpu device, suggest to use it when achieve more than 80% gpu-until
    int __stdcall JSSJ_BF_RegisterMemory(void *memory, size_t memory_size);
    // unregister memory page-lock
    int __stdcall JSSJ_BF_UnregisterMemory(void *memory);
    // bf_img init, need memory_size & storage_format
    int __stdcall JSSJ_BF_InitImg(JSDJ_BF_Image *bf_img);
    // bf_image release
    int __stdcall JSSJ_BF_ReleaseImg(JSDJ_BF_Image *bf_img);
    // bf_image copy
    int __stdcall JSSJ_BF_CopyImg(JSDJ_BF_Image *input_bf_img, JSDJ_BF_Image *output_bf_img);
    // bf init
    int __stdcall JSSJ_BF_Init(JSDJ_BF_InitParam *init_param, void **module_handle);
    // bf release
    int __stdcall JSSJ_BF_Release(void **module_handle);
    // bf get last error string
    int __stdcall JSSJ_BF_GetLastErrorString(void *handle, int error_code, char *error_string, const int error_string_size);
    // process functions
    // image resize, must input width & height of output_image
    int __stdcall JSSJ_BF_Resize(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // image resize nearest neighbor
    int __stdcall JSSJ_BF_ResizeNN(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // image roi resize, input_roi follows format of two points(left up & right down: x1,y1,x2,y2), roi_num [1, 128] for each image
    int __stdcall JSSJ_BF_ResizeRoi(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, int *input_roi, int *roi_num, JSDJ_BF_Image *output_image);
    // image resize as opencv's area
    int __stdcall JSSJ_BF_ResizeArea(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // image resize follow opencv, clamp_type 0 for fill 0 and else for clamp down
    int __stdcall JSSJ_BF_ResizeCV(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image, int clamp_type);
    // image roi resize follow opencv, input_roi follows format of two points(left up & right down: x1,y1,x2,y2), roi_num [1, 128] for each image, clamp_type 0 for fill 0 and else for clamp down
    int __stdcall JSSJ_BF_ResizeRoiCV(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, int *input_roi, int *roi_num, JSDJ_BF_Image *output_image, int clamp_type);
    // image format conversion
    int __stdcall JSSJ_BF_FormatConv(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // warp affine no shear. points_num [2 64]
    int __stdcall JSSJ_BF_WarpAffineNoShear(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num,
        JSDJ_BF_Point *src_points, JSDJ_BF_Point *dst_points, const int points_num, JSDJ_BF_Image *output_image);
    // warp affine. points_num [3 64]
    int __stdcall JSSJ_BF_WarpAffine(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num,
        JSDJ_BF_Point *src_points, JSDJ_BF_Point *dst_points, const int points_num, JSDJ_BF_Image *output_image);
    // warp perspective. points_num [4 64]
    int __stdcall JSSJ_BF_WarpPerspective(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num,
        JSDJ_BF_Point *src_points, JSDJ_BF_Point *dst_points, const int points_num, JSDJ_BF_Image *output_image);
#else
    // Get valid cuda device number, by set the gpu_sm to find the device beyond it                                               
    int JSSJ_BF_GetGpuDeviceNum(const float gpu_sm, int *gpu_device_num);
    // set GPU device for host thread, a default device will be set without calling
    int JSSJ_BF_SetGpuDevice(const float gpu_sm, const int gpu_device_id);
    // set GPU device flags, If the current device has been set and that device has already been initialized then this call will fail
    // 0 for auto, 1 for actively spin, 2 for yield(mutil-card)
    int JSSJ_BF_SetGpuDeviceFlags(unsigned int flags);
    // reset GPU device, Destroy all allocations and reset all state on the current device in the current process
    int JSSJ_BF_RetGpuDevice();
    // register memory page-lock, it accelerate process functions in gpu device, suggest to use it when achieve more than 80% gpu-until
    int JSSJ_BF_RegisterMemory(void *memory, size_t memory_size);
    // unregister memory page-lock
    int JSSJ_BF_UnregisterMemory(void *memory);
    // bf_img init
    int JSSJ_BF_InitImg(JSDJ_BF_Image *bf_img);
    // bf_image release
    int JSSJ_BF_ReleaseImg(JSDJ_BF_Image *bf_img);
    // bf_image copy
    int JSSJ_BF_CopyImg(JSDJ_BF_Image *input_bf_img, JSDJ_BF_Image *output_bf_img);
    // bf init
    int JSSJ_BF_Init(JSDJ_BF_InitParam *init_param, void **module_handle);
    // bf release
    int JSSJ_BF_Release(void **module_handle);
    // bf get last error string
    int JSSJ_BF_GetLastErrorString(void *handle, int error_code, char *error_string, const int error_string_size);
    // process functions
    // image resize, must input width & height of output_image
    int JSSJ_BF_Resize(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // image resize nearest neighbor
    int JSSJ_BF_ResizeNN(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // image roi resize, input_roi follows format of two points(left up & right down: x1,y1,x2,y2), roi_num [1, 128] for each image
    int JSSJ_BF_ResizeRoi(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, int *input_roi, int *roi_num, JSDJ_BF_Image *output_image);
    // image resize as opencv's area
    int JSSJ_BF_ResizeArea(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // image resize follow opencv, clamp_type 0 for fill 0 and else for clamp down
    int JSSJ_BF_ResizeCV(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image, int clamp_type);
    // image roi resize follow opencv, input_roi follows format of two points(left up & right down: x1,y1,x2,y2), roi_num [1, 128] for each image, clamp_type 0 for fill 0 and else for clamp down
    int JSSJ_BF_ResizeRoiCV(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, int *input_roi, int *roi_num, JSDJ_BF_Image *output_image, int clamp_type);
    // image format conversion
    int JSSJ_BF_FormatConv(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num, JSDJ_BF_Image *output_image);
    // warp affine no shear. points_num [2 64]
    int JSSJ_BF_WarpAffineNoShear(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num,
        JSDJ_BF_Point *src_points, JSDJ_BF_Point *dst_points, const int points_num, JSDJ_BF_Image *output_image);
    // warp affine. points_num [3 64]
    int JSSJ_BF_WarpAffine(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num,
        JSDJ_BF_Point *src_points, JSDJ_BF_Point *dst_points, const int points_num, JSDJ_BF_Image *output_image);
    // warp perspective. points_num [4 64]
    int JSSJ_BF_WarpPerspective(void *module_handle, JSDJ_BF_DeviceType device_type, JSDJ_BF_Image *input_image, const int input_image_num,
        JSDJ_BF_Point *src_points, JSDJ_BF_Point *dst_points, const int points_num, JSDJ_BF_Image *output_image);
#endif
#ifdef    __cplusplus
}
#endif
#endif
