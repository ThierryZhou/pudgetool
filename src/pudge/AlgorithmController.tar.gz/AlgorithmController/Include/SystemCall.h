#ifndef __SYSTEM_CALL_H__
#define __SYSTEM_CALL_H__

#include <cuda.h>
#include "nvml.h"
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>  
#include <sched.h>
#include <string.h>
#include <memory>
#include <iostream>

#define CheckNvmlRet(Result) if( Result != NVML_SUCCESS ) { \
    return; \
    }

#define ck(call) check(call, __LINE__, __FILE__)

static int GetMaskNum(unsigned long value)
{
    if (value == 1)
        return 0;
    else
        return 1 + GetMaskNum(value >> 1);
};

static void GetGpuAffinity(int nGpuIndex, unsigned long** ppMask, unsigned int* pMaskNum)
{
    static unsigned long** ppCpuMask = NULL;
    static unsigned int iGpuNum = 0;
    static unsigned int iCpuNum = 0;

    int iCpuSetMaskNum = 0;
    unsigned long cpuSetMask = 0;
    unsigned int cpuSetSize = 2;

    char device_name[NVML_DEVICE_NAME_BUFFER_SIZE] = {0};

    nvmlReturn_t result;
    nvmlDevice_t device;

    if (NULL == ppCpuMask)
    {
        result = nvmlInit();
        CheckNvmlRet(result);

        // got current system's gpu numbers
        result = nvmlDeviceGetCount(&iGpuNum);
        CheckNvmlRet(result);

        // got current system's cpu numbers
        iCpuNum = sysconf(_SC_NPROCESSORS_CONF);

        ppCpuMask = new unsigned long*[iGpuNum];
        for (unsigned int i = 0; i < iGpuNum; ++i)
        {
            ppCpuMask[i] = new unsigned long[iCpuNum];
            memset(ppCpuMask[i], 0, iCpuNum * sizeof(unsigned long));
        }

        for (unsigned int i = 0; i < iGpuNum; ++i)
        {
            result = nvmlDeviceGetHandleByIndex(i, &device);
            CheckNvmlRet(result);

            result = nvmlDeviceGetName(device, device_name, NVML_DEVICE_NAME_BUFFER_SIZE);
            CheckNvmlRet(result);

            result = nvmlDeviceGetCpuAffinity(device, cpuSetSize, &cpuSetMask);
            CheckNvmlRet(result);

            iCpuSetMaskNum = GetMaskNum(cpuSetMask);

            for (int j = iCpuSetMaskNum; j >= 0; --j) 
            {
                ppCpuMask[i][j] = ((cpuSetMask >> (j)) & 1);
            }
        }
        nvmlShutdown();
    }

    unsigned long szCpuMask[iCpuNum];
    *pMaskNum = 0;
    for (size_t i = 0; i < iCpuNum; i++)
    {
        if ( 1 == ppCpuMask[nGpuIndex][i] )
        {
            szCpuMask[(*pMaskNum)] = i;
            ++(*pMaskNum);
        }
    }
    *ppMask = new unsigned long[*pMaskNum];
    memcpy(*ppMask, szCpuMask, (*pMaskNum) * sizeof(unsigned long));
};

static void setCpuAffinity(unsigned long *pMask, int nMaskNum)
{
    cpu_set_t mask;
    CPU_ZERO(&mask);

    for (int i = 0; i < nMaskNum; ++i)
    {
        CPU_SET(pMask[i], &mask);
    }

    // if (sched_setaffinity(0, sizeof(mask), &mask) == -1)
    // {
    //     printf("set CPU affinity error!\n");
    // }
    if( -1 == pthread_setaffinity_np(pthread_self(), sizeof(mask), &mask) )
    {  
        fprintf(stderr, "pthread_setaffinity_np erro\n");  
    }  
}

/** 
 * @brief 设置当前进程优先级最低
 * @param int policy  进程调度方式（一般情况下默认使用SCHED_OTHER，如需优化使用SCHED_RR）
 *
 * @return 返回说明
 *     < 0, 错误; = 0, 正确
 */          
static int setProcessPriMin(int policy)
{
    struct sched_param param; 
    int minpri = 0;
    minpri = sched_get_priority_min(policy);            
    if(minpri == -1) 
    { 
        perror("sched_get_priority_max() failed"); 
        return -1; 
    } 
    param.sched_priority = minpri; 
    if (sched_setscheduler(getpid(), policy, &param) == -1) //设置优先级
    { 
        perror("sched_setscheduler() failed"); 
        return -1;
    }

    return 0;   
}

/** 
 * @brief 设置当前进程优先级最高
 * @param int policy  进程调度方式（一般情况下默认使用SCHED_OTHER，如需优化使用SCHED_RR）
 *
 * @return 返回说明
 *     < 0, 错误; = 0, 正确
 */   
static int setProcessPriMax(int policy)
{
    struct sched_param param; 
    int maxpri = 0;
    maxpri = sched_get_priority_max(policy);            
    if(maxpri == -1) 
    { 
        perror("sched_get_priority_max() failed"); 
        return -1; 
    } 
    param.sched_priority = maxpri; 
    if (sched_setscheduler(getpid(), policy, &param) == -1) //设置优先级
    { 
        perror("sched_setscheduler() failed"); 
        return -1;
    }

    return 0;
}

#endif
