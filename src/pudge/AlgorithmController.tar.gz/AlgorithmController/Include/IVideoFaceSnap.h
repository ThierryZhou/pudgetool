/*****************************************************************
Copyright (C), 2018, iCare Vision Tech. Co., Ltd.
All rights reserved

FileName: IVideoFaceSnap.h
Description: 抓拍算法接口头文件

History:
<author>		<time>		<version>		<Abstract>
 周辉		  2018-12      		1.0.0			创建此文件
*****************************************************************/
#ifndef __VIDEOFACESNAP_H__
#define __VIDEOFACESNAP_H__

#ifndef WIN32
#define __VFS_STD_CALL__
#else
#define __VFS_STD_CALL__ __stdcall
#endif

#define MAX_PATH 255
#define MAX_GPU_DEV	16
#define __IN__
#define __OUT__

typedef enum VFS_DEVICE_TYPE
{
	VFC_CPU_DEVICE = 0,
	VFC_GPU_DEVICE = 1,
}VFS_DEVICE_TYPE;

typedef enum VFS_TRACK_PROP
{
	TRACK_PROP_NORMAL = 0x01,		//正常跟踪
	TRACK_PROP_NEW = 0X02,			//新建目标
	TRACK_PROP_DISAPPEAR = 0x04,	//消失
	TRACK_PROP_ERROR     = 0x08     // 错误 Add djbao 2017.2.26
}VFS_TRACK_PROP;

typedef enum VFS_FLD_TYPE{
	FLD_TYPE_MOUTH	= 0x01,
	FLD_TYPE_SHAKE	= 0x02,
	FLD_TYPE_NOD	= 0x04,
}VFS_FLD_TYPE;

typedef struct VFS_InitParam
{
	int			nMaxWidth;				//最大可处理的视频图像宽
	int			nMaxHeight;				//最大可处理的视频图像高
	int			nImgfmt;				//图像编码，0:H264
	int			nChanNum;				//最大视频路数，默认为20
	char*		pModelDir;				//模型地址
	int			szDeviceList[MAX_GPU_DEV];			//可以访问的GPU设备列表
	int			nDeviceNum;				//设备数量
}VFS_InitParam;

typedef struct VFS_chanParam
{
	int			dwMinFaceSize;			//最小人脸框
	int			nVideoWidth;			//视频图像宽
	int			nVideoHeight;			//视频图像高
	int			dwFCModel;				//抓拍模式，0:跟踪过程中抓拍所有符合要求的所有人脸,1:整个跟踪过程抓拍一张最清晰的人脸,2:指定帧数内抓拍一张最清晰的人脸
	int			dwTimeOutFramesCount;	//抓拍超时帧数，针对dwFCModel=0的情况，在设置的帧数内抓拍不到满足要求的人脸时强制输出跟踪过程中相对最佳的人脸≥5
	int			dwIVSFlag;				//IVS开关，0:close,1:open
	int			*pdwROI;				//设置ROI区域，全图可设置为NULL，否则输入区域的顶点坐标以-1结束（x0,y0,x1,y1,....,-1）
	int			dwLocalSnapInterval;	//局部抓拍间隔，dwFCModel=2时有效，每隔dwLocalSnapInterval帧抓拍一张这段时间内最好的人脸
	int         dwDeviceType;           //见VFC_DEVICE_TYPE结构体
	int			nImageFmt;				//图像编码，0:H264
}VFS_chanParam; 

typedef struct VFS_FaceObject
{
    int 			dwTrackId;                  //跟踪id
    int 			dwTrackProp;                //跟踪标识
    int*			pdwFaceBox;                	//人脸包围盒（左上角、右下角）
    int 			dwFaceImgProp;              //0:没有报警图像；1:有报警图像
    float*			pfFaceLandmarks;         	//人脸特征点坐标基于报警图的坐标
    int 			dwAlarmImgWidth;            //报警图像宽度
    int 			dwAlarmImgHeight;           //报警图像高度
    unsigned char*	pubyAlarmImg;    			//报警图数据
    int*			pdwAlarmFaceBox;           	//报警图的人脸包围盒
    int 			dwAlarmFaceScore;           //报警人脸得分；满分100分，分数越高质量越好
    int 			dwObjectLeaveState;         //目标离开状态；0：表示正常状态; 1：表示中间离开；2：表示边界离开
}VFS_FaceObject;

typedef struct VFS_VideoFaceInfo
{
    int 				dwFaceNum;                 //人脸个数
    int 				dwLandmarkSize;            //特征点个数
    int 				dwFaceImgFmt;
    VFS_FaceObject*		pdjFaceObject;
}VFS_VideoFaceInfo;

struct VFSInstance;

#ifdef __cplusplus
extern "C"
{
#endif

/*****************************************************************************
* @function		iCare_VFS_Init
* @brief VFS模块初始化
* @note 调用此函数后必须调用反初始化函数 iCare_VFS_Uninit
* @param
*		[in] VFS_InitParam* initParam 初始化输入参数
* @return 
* 	struct VFSInstance* 返回VFS实例指针
*****************************************************************************/
struct VFSInstance* __VFS_STD_CALL__ iCare_VFS_Init(VFS_InitParam* __IN__ initParam);

/*****************************************************************************
* @function		iCare_VFS_newChan
* @brief 添加视频通道
* @note 调用此函数后必须调用反初始化函数 iCare_VFS_ChanUninit
* @param
*		[in] struct VFSInstance*		vfsHandle		VFS模块实例指针（调用iCare_VFS_Uninit得到）
*		[in] struct VFS_chanParam* 		chanParam		初始化输入参数
* @return 
* 	int 返回视频通道号
*****************************************************************************/
int __VFS_STD_CALL__ iCare_VFS_newChan(struct VFSInstance* __IN__ vfsHandle, struct VFS_chanParam* __IN__ chanParam);

/*****************************************************************************
* @function		iCare_VFS_delChan
* @brief 删除视频通道
* @note 调用此函数后必须调用反初始化函数 iCare_VFS_ChanUninit
* @param
*		[in] struct VFSInstance*		vfsHandle		VFS模块实例指针（调用iCare_VFS_Uninit得到）
*		[in] int						nChannelIdx		视频通道号
* @return 
* 	int 返回视频通道号
*****************************************************************************/
int __VFS_STD_CALL__ iCare_VFS_delChan(struct VFSInstance* __IN__ vfsHandle, int nChannelIdx);

/*****************************************************************************
* @function		iCare_VFS_Process
* @brief 传入一帧视频进行人脸抓拍检测
* @note 调用此函数后必须调用反初始化函数 iCare_VFS_Uninit
* @param
*		[in] struct VFSInstance* __IN__ vfsHandle VFS模块实例（调用iCare_VFS_Uninit得到）
*		[in] int __IN__ nChanIdx		视频通道序号
*		[in] const char* __IN__ pData 	视频帧数据
*		[in] const int __IN__	nLen	视频帧数据长度
*		[out] struct VFSVideoFaceInfo** __OUT__ ppdjVFCVideoFaceInfo 人脸检测结果
* @return 
* 		int	返回值 >= 0 表示成功;< 0 表示错误
*****************************************************************************/
int __VFS_STD_CALL__ iCare_VFS_Process(struct VFSInstance* __IN__ vfsHandle, int __IN__ nChanIdx, const unsigned char* __IN__ pData, int __IN__ nLen, VFS_VideoFaceInfo** __OUT__ ppdjVFCVideoFaceInfo);

/*****************************************************************************
* @function		iCare_VFS_ProcessEnd
* @brief 结束一个视频通道的人脸抓拍检测
* @note 调用此函数后必须调用反初始化函数 iCare_VFS_Uninit
* @param
*		[in] struct VFSInstance* __IN__ vfsHandle VFS模块实例（调用iCare_VFS_Uninit得到）
*		[in] int __IN__ nChanIdx		视频通道序号
*		[in] const char* __IN__ pData 	视频帧数据
*		[in] const int __IN__	nLen	视频帧数据长度
*		[out] struct VFSVideoFaceInfo** __OUT__ ppdjVFCVideoFaceInfo 人脸检测结果
* @return 
* 		int	返回值 >= 0 表示成功;< 0 表示错误
*****************************************************************************/
int __VFS_STD_CALL__ iCare_VFS_ProcessEnd(struct VFSInstance* __IN__ vfsHandle, int __IN__ nChanIdx, VFS_VideoFaceInfo** __OUT__ ppdjVFCVideoFaceInfo);

/*****************************************************************************
* @function		iCare_VFS_Uninit
* @brief VFS模块反初始化
* @note 
* @param
*		[in] struct VFSInstance* __IN__ vfsHandle VFS模块实例（调用iCare_VFS_Uninit得到）
* @return 
* 		void
*****************************************************************************/
void __VFS_STD_CALL__ iCare_VFS_Uninit(struct VFSInstance* __IN__ vfsHandle);

#ifdef __cplusplus
}
#endif

/*****************************************************************************
 * code example：
 * 		
 * 		VFS_InitParam iniParam = {0};
 * 		struct VFSInstance* inst = VFS_SystemInit(&iniParam);
 * 		
 * 		int nChanIdx = 0;
 * 		char szVideo[MAX_FRAME_LEN];
 * 		VFSVideoFaceInfo *pdjVFCVideoFaceInfo;
 * 		iCare_VFS_Process(inst, nChanIdx, szVideo, MAX_FRAME_LEN, &pdjVFCVideoFaceInfo);
 * 
 * 		
 * 		iCare_VFS_Uninit(inst);
 * 		exit(0);
 * 
 ******************************************************************************/

#endif