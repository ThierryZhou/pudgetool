/*****************************************************************
Copyright (C), 2018, iCare Vision Tech. Co., Ltd.
All rights reserved

FileName: ICareAlgAnalyzeBase.hpp
Description: 算法分析基类

History:
<author>        <time>        <version>        <Abstract>
 周辉          2018-12              1.0.0            创建此文件
*****************************************************************/
#pragma once

#include "VFACodecDefine.h"

#include <memory>
#include <thread>

namespace alg_controller{

class CICareAlgAnalyzeBase
{
public:
    CICareAlgAnalyzeBase()
    {
    };

    explicit CICareAlgAnalyzeBase(const char* pModelPath)
    {
        if ( pModelPath )
        {
            m_strModelPath = pModelPath;
        }
    };
    
    virtual ~CICareAlgAnalyzeBase()
    {
    };

public:
    void init(int nHeight, int nWidth, int image_fmt, int nChannel)
    {
        m_nHeight = nHeight;
        m_nWidth = nWidth;
        m_ImageFmt = image_fmt;
        m_nChannel = nChannel;

        init(nHeight, nWidth);
    };


public:
    virtual void init(int nHeight, int nWidth) {};

    virtual void uninit() {};

    virtual int AlgProcess(VFSFrame* vFrame, VFAPacket** ppOutFrame) { return 0; };

public:
    int m_nheight = 0;
    int m_nwidth = 0;
    int m_imagefmt = 0;
    int m_nwidthstep = 0;
    int m_nchannel = 0;

    void*       m_hAlg = nullptr;
    std::string m_strModelPath = "";
    VFAPacket*  m_pOutPack = nullptr;
};

} //namespace alg_controller
