#pragma once

#include "VFACodecDefine.h"
#include "ICareAlgDefine.h"
#include "ICareAlgChannel.hpp"
#include <memory>
#include <thread>
#include <deque>
#include <vector>
#include <mutex>
#include <condition_variable>

namespace alg_controller{

class CICareAlgSnapshotBase;

/**
 * @Brief 设备类
 * @Detail 每接入一个视频就创建一个对应的视频通道类对象与之对应，
 *  一个对象包含一个解码器对象和一个转发算法实例对象
 */
template<typename TSnap, typename TAly>
class CICareAlgDevice : public std::enable_shared_from_this<CICareAlgDevice<TSnap, TAly>>
{
public:
    CICareAlgDevice();
    virtual ~CICareAlgDevice();

public:
    void init(int height, int width, int image_fmt, int device_index, int max_channel, const char* pModel)
    {
        m_pDevInfo = std::make_shared<DeviceInfo>();
        if( !m_pDevInfo )
        {
            m_pDevInfo->init(height, width, image_fmt, device_index, max_channel, pModel);
        }

        m_nMaxChannel = max_channel;

        // LOG(INFO) << "CICareAlgDevice object(GPU:" << m_nDeviceIdx << ") init successful:";
    };

    void uninit()
    {
        if( !m_pDevInfo )
        {
            m_pDevInfo->uninit();
        }

        int nAvaNum = m_arrVideoChansStop.size();
        for(int i=0; i<nAvaNum; ++i)
        {
            m_arrVideoChansStop[i]->uninit();
        }
        m_arrVideoChansStop.clear();

        int nRunNum = m_arrVideoChansRun.size();
        for(int i=0; i<nRunNum; ++i)
        {
            m_arrVideoChansRun[i]->uninit();
        }
        m_arrVideoChansRun.clear();

        // LOG(INFO) << "CICareAlgDevice object(GPU:" << m_nDeviceIdx << ") uninit successful:";
    };

    int newChannel(int height, int width, int image_fmt)
    {
        // int nChaNum = 0;
        int nChanIndex = 0;
        std::shared_ptr<CICareAlgChannel<TSnap>> ptrVideoChannel;
        {
            std::lock_guard<std::mutex> channelLock(m_mutChannel);   
            int nAvaNum = m_arrVideoChansStop.size();
            if( nAvaNum > 0 )
            {
                ptrVideoChannel = m_arrVideoChansStop[0];
                m_arrVideoChansRun.push_back(ptrVideoChannel);
                m_arrVideoChansStop.pop_front();
                return m_arrVideoChansRun.size() - 1;
            }

            ptrVideoChannel = std::make_shared<CICareAlgChannel<TSnap>>();
            m_arrVideoChansRun.push_back(ptrVideoChannel);

            nChanIndex = m_arrVideoChansRun.size() - 1;
        }

        bindGPUDvice(getDeviceIdx());

        // CICareAlgChannel<TSnap>::RunProc(ptrVideoChannel, getDeviceIdx(), nChanIndex);
        // std::function<std::shared_ptr<CICareAlgChannel<TSnap>>,int,int> funRunProc = CICareAlgChannel<TSnap>::RunProc;
        std::thread newRunThead(&CICareAlgChannel<TSnap>::RunProc, ptrVideoChannel, getDeviceIdx(), nChanIndex);
        ptrVideoChannel->init(height, width, image_fmt, nChanIndex, getDeviceIdx(), std::move(newRunThead));

        // LOG(INFO) << "CICareAlgDevice:" << m_nDeviceIdx << ", add video channel (Id:" << nChanIndex << ").";

        return nChanIndex;
    }

    int delChannel(int nChannel)
    {
        std::lock_guard<std::mutex> channelLock(m_mutChannel);
        // typedef std::deque<std::shared_ptr<CICareAlgChannel<TSnap>>>::itorate;
        for(auto itor = m_arrVideoChansRun.begin(); itor != m_arrVideoChansRun.end();)
        {
            if ( nChannel == (*itor)->m_nVideoChanIdx )
            {
                m_arrVideoChansStop.push_back(*itor);
                m_arrVideoChansRun.erase(itor);
                return 0;
            }
            else
            {
                itor++;
            }
        }

        return -1;
    }

    int doProcess(int nChannel, const unsigned char* pData, unsigned int nLen, VFAPacket** outPacket)
    {
        int nChanNum = m_arrVideoChansRun.size();
        if (nChannel > nChanNum)
        {
            LOG(ERROR) << "Can't find Channel(" << nChannel << ")!";
            return -1;
        }
        std::shared_ptr<CICareAlgChannel<TSnap>> ptrChannel = m_arrVideoChansRun[nChannel];
        if( !ptrChannel )
        {
            LOG(ERROR) << "Got Channel(" << nChannel << ") is Failed!";
            return -1;
        }

        if ( !pData && 0 == nLen )
        {
            ptrChannel->NotifyRunProc();
            LOG(INFO) << "the last frame in channel:" << nChannel << ".";

            ptrChannel->WaitPopPack(0);
            ptrChannel->m_bOutProc = false;
            *outPacket = ptrChannel->pOutPack;

            LOG(INFO) << "got the last frame pop packet in channel:" << nChannel << ".";

            return 1;
        }

        VFSFrame* pInFrame = AllocVFSFrame(ptrChannel->m_nHeight, ptrChannel->m_nWidth, nLen, H264, false);
        std::shared_ptr<CICareAlgDecoder> ptrDec = ptrChannel->ptrDecoder;
        int nRet = CopyData2VFSFrame(pInFrame, pData, nLen);
        if( nRet < 0 )
        {
            LOG(ERROR) << "Copy Data is Failed!";
            return -1;
        }

        int nFrameIdx = ptrDec->PushAndNodify(pInFrame);

        ptrChannel->NotifyRunProc();
        ptrChannel->WaitPopPack(1);
        ptrChannel->m_bOutProc = false;
        *outPacket = ptrChannel->pOutPack;

        FreeVFSFrame(&pInFrame);
        pInFrame = nullptr;

        // LOG(INFO) << "output packet:" << *outPacket;

        return 1;
    }

    bool isFullLoad()
    {
        std::lock_guard<std::mutex> channelLock(m_mutChannel);
        return m_arrVideoChansRun.size() == (unsigned int)m_nMaxChannel ? true : false;
    };

    bool isIdle()
    {
        std::lock_guard<std::mutex> channelLock(m_mutChannel);
        return  m_arrVideoChansRun.size() == 0 ? true : false;
    };

    int getDeviceIdx()
    {
        return m_pDevInfo->m_nDeviceIdx;
    };
private:
    std::vector<std::shared_ptr<CICareAlgSnapshotBase>> m_arrAlgIns;
    std::deque<std::shared_ptr<CICareAlgChannel<TSnap>>> m_arrVideoChansRun;
    std::deque<std::shared_ptr<CICareAlgChannel<TSnap>>> m_arrVideoChansStop;

private:
    int m_nMaxChannel = 0;
    std::mutex  m_mutChannel;
    std::shared_ptr<DeviceInfo> m_pDevInfo;
    // std::string m_strDeviceName;
};

}; //namespace alg_controller
