#pragma once

#include "VFADecoder.hpp"

typedef CVFSDecoder CICareAlgDecoder;
