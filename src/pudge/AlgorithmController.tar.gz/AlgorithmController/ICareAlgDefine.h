#ifndef __ICAREALGDEFINE_H__
#define __ICAREALGDEFINE_H__

#include <string.h>

class DeviceInfo
{

public:
    DeviceInfo() {};
    ~DeviceInfo() {};

    void init(int height, int width, int image_fmt, int device_index, int max_channel, const char* pModel)
    {
        m_nDeviceIdx = device_index;
        m_nMaxChannel = max_channel;
        m_nMaxHeight = height;
        m_nMaxWidth = width;
        m_ImageFmt = image_fmt;
        m_strModelPath = pModel;
    };

    void uninit()
    {
        m_nDeviceIdx = 0;
        m_nMaxChannel = 0;
        m_nMaxHeight = 0;
        m_nMaxWidth = 0;
        m_ImageFmt = 0;
        m_strModelPath = "";
    };

public:
    int         m_ImageFmt = 0;
    int         m_nMaxHeight = 0;
    int         m_nMaxWidth = 0;
    int         m_nDeviceIdx = 0;
    int         m_nMaxChannel = 0;
    std::string m_strModelPath = "";
};

#endif