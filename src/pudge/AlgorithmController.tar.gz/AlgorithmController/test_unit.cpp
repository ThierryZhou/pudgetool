#ifdef TEST_UNIT

#include "IICareAlgController.h"
#include "FFmpegDemuxer.h"
#include <thread>
#include <memory>
#include <mutex>

#define MAX_FRAME_LEN 255

int main(int argc, char* argv[])
{
    VFS_InitParam initParam = {0};
    initParam.nMaxHeight = 1080;
    initParam.nMaxWidth = 1920;
    initParam.nImgfmt = 0;
    initParam.nChanNum = 18;
    initParam.pModelDir = "./Model";
    initParam.szDeviceList[0] = 0;
    initParam.nDeviceNum = 1;
    struct VFSInstance* pInstance = iCare_VFS_Init(&initParam);
    
    VFS_chanParam chanParam = {0};
    chanParam.nVideoWidth = 1080;
    chanParam.nVideoHeight = 1920;
    chanParam.dwDeviceType = 1;
    int nChanIdx = iCare_VFS_newChan(pInstance, &chanParam);
    char szVideo[MAX_FRAME_LEN];
    VFS_VideoFaceInfo* pdjVFCVideoFaceInfo = NULL;

    char szInFilePath[MAX_FRAME_LEN];
    strcpy(szInFilePath, "rtsp://172.16.4.27:8554/new-2.264");
    std::unique_ptr<FFmpegDemuxer> ptrDemuxer(new FFmpegDemuxer(szInFilePath));
    int width = ptrDemuxer->GetWidth();
    int height = ptrDemuxer->GetHeight();
    int nVideoBytes = 0;
    int nRet = 0;
    uint8_t *pVideo = NULL;
    while(true)
    {
        ptrDemuxer->Demux(&pVideo, &nVideoBytes);
        nRet = iCare_VFS_Process(pInstance, nChanIdx, (unsigned char*)pVideo, nVideoBytes, &pdjVFCVideoFaceInfo);
        if( nRet < 0 )
        {
            printf("encounter some errors.");
            return 0;
        }
    }
    
    iCare_VFS_Uninit(pInstance);
    exit(0);

    return 0;
}

#endif