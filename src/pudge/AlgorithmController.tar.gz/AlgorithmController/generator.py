#! /usr/bin/env python
#coding=utf-8
#author zhouh zhouhui295@163.com 2014-7-22
import os,sys,re,traceback
from datetime import datetime
from string import Template

class CodeGenerator:
    def __init__(self, project_name):
        
        #save class name
        self.projName = project_name 

        #generate class abb name
        self.projAbb = ''
        for i in range(len(self.projName)):
            if self.projName[i].isupper():
                self.projAbb += self.projName[i]

    def gen_snapshot(self):
        '''
            generate snapshot class
        '''
        className = '%sSnapshot' % self.projAbb
        classAbb = self.projAbb
        classMicro = className.upper()

        #generate source file and header file
        SnapSrcFile = open('%s.cpp' % className, "w")
        SnapHeadFile = open('%s.hpp' % className, "w")

        template_snapshot_source = open(r'ICareAlgCppExtend.template', 'r')
        template_snapshot_header = open(r'ICareAlgHppExtend.template', 'r')
        tmp_snap_src = Template(template_snapshot_source.read())
        tmp_snap_head = Template(template_snapshot_header.read())
        tmp_snap_lines = []
        tmp_snap_lines.append(tmp_snap_src.safe_substitute(
            CLASS_NAME = className,
            CLASS_ABB = classAbb,
            CLASS_MICRO = classMicro,
            PARENT_CLASS = 'ICareAlgSnapshotBase',
            GENE_DATE = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        SnapSrcFile.writelines(tmp_snap_lines)
        SnapSrcFile.close()

        tmp_snap_lines = []
        tmp_snap_lines.append(tmp_snap_head.safe_substitute(
            CLASS_NAME = className,
            CLASS_ABB = classAbb,
            CLASS_MICRO = classMicro,
            PARENT_CLASS = 'ICareAlgSnapshotBase',
            GENE_DATE = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        SnapHeadFile.writelines(tmp_snap_lines)
        SnapHeadFile.close()

        print('generate %s over.' % className)

    def gen_analyze(self):
        '''
            generate analyze class
        '''
        className = '%sAnalyze' % self.projAbb
        classAbb = self.projAbb
        classMicro = className.upper()

        AlySrcFile = open('%s.cpp' % className, "w")
        AlyHeadFile = open('%s.hpp' % className, "w")

        template_analyze_source = open(r'ICareAlgCppExtend.template', 'r')
        template_analyze_header = open(r'ICareAlgHppExtend.template', 'r')
        tmp_aly_src = Template(template_analyze_source.read())
        tmp_aly_head = Template(template_analyze_header.read())
        
        tmp_aly_lines = []
        tmp_aly_lines.append(tmp_aly_src.safe_substitute(
            CLASS_NAME = className,
            CLASS_ABB = classAbb,
            CLASS_MICRO = classMicro,
            PARENT_CLASS = 'ICareAlgAnalyze',
            GENE_DATE = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        AlySrcFile.writelines(tmp_aly_lines)
        AlySrcFile.close()

        tmp_aly_lines = []
        tmp_aly_lines.append(tmp_aly_head.safe_substitute(
            CLASS_NAME = className,
            CLASS_ABB = classAbb,
            CLASS_MICRO = classMicro,
            PARENT_CLASS = 'ICareAlgAnalyze',
            GENE_DATE = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        AlyHeadFile.writelines(tmp_aly_lines)
        AlyHeadFile.close()

        print('generate %s over.' % className)
    
    def gen_interface(self):
        '''
            generate project interface source and header
        '''
        className = '%sInterface' % self.projName
        classAbb = self.projAbb
        classMicro = className.upper()

        #generate source file and header file
        InterSrcFile = open('%s.cpp' % className, "w")

        template_source = open(r'InterfaceSource.template', 'r')

        tmp_inter_src = Template(template_source.read())
        tmp_inter_lines = []
        tmp_inter_lines.append(tmp_inter_src.safe_substitute(
            CLASS_NAME = className,
            CLASS_ABB = classAbb,
            CLASS_MICRO = classMicro,
            GENE_DATE = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        InterSrcFile.writelines(tmp_inter_lines)
        InterSrcFile.close()
        
        InteHeadFile = open('%s.h' % className, "w")
        template_header = open(r'InterfaceHeader.template', 'r')
        tmp_inter_head = Template(template_header.read())
        tmp_inter_lines = []
        tmp_inter_lines.append(tmp_inter_head.safe_substitute(
            CLASS_NAME = projName,
            CLASS_ABB = classAbb,
            CLASS_MICRO = classMicro,
            GENE_DATE = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        InteHeadFile.writelines(tmp_inter_lines)
        InteHeadFile.close()

        print('generate %s over.' % className)

    def gen_cmake(self):
        '''
            generate CMake source file
        '''
        #generate source file and header file
        cmake_file = open('CMakeLists.txt', "w")
        template_source = open(r'CMakeLists.template', 'r')
        tmp_inter_src = Template(template_source.read())
        tmp_inter_lines = []
        tmp_inter_lines.append(tmp_inter_src.safe_substitute(
            PROJECT_NAME = self.projName,
            GENE_DATE = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        ))
        cmake_file.writelines(tmp_inter_lines)
        cmake_file.close()

        print('generate CMakeLists.txt over.')

    def gen_makefile(self):
        pass

if __name__ == "__main__":
    if len(sys.argv) < 2:
        PRINT('does not set enough params.')
    projName = sys.argv[1]
    cgenerator = CodeGenerator(projName)
    cgenerator.gen_snapshot()
    cgenerator.gen_analyze()
    cgenerator.gen_interface()
    cgenerator.gen_cmake()
