/*****************************************************************
Copyright (C), 2018, iCare Vision Tech. Co., Ltd.
All rights reserved

FileName: ICareAlgSnapshotBase.hpp
Description: 算法抓拍基类

History:
<author>        <time>        <version>        <Abstract>
 周辉          2018-12              1.0.0            创建此文件
*****************************************************************/
#pragma once

#include "VFACodecDefine.h"

#include <memory>
#include <thread>

namespace alg_controller{

class CICareAlgSnapshotBase
{
public:
    CICareAlgSnapshotBase()
    {

    };

    explicit CICareAlgSnapshotBase(const char* pModelPath)
    {
        m_strModelPath = pModelPath;
    };

    virtual ~CICareAlgSnapshotBase()
    {
        m_strModelPath = "";
    };

public:
    void init(int nHeight, int nWidth, int image_fmt, int nChannel)
    {
        m_nHeight = nHeight;
        m_nWidth = nWidth;
        m_nChannel = nChannel;
        m_ImageFmt = image_fmt;

        init(nHeight, nWidth);
    };

public:
    virtual void init(int nHeight, int nWidth) {};
    virtual void uninit() {};

    virtual int AlgProcess(VFSFrame* vFrame, VFAPacket** ppOutFrame) { return 0; };
 
public:
    int m_nHeight = 0;
    int m_nWidth = 0;
    int m_nWidthStep = 0;
    int m_nChannel = 0;

    void*           m_hAlg = nullptr;
    std::string     m_strModelPath = "";
    VFAPacket*      m_pOutPack = nullptr;
};

}; //namespace alg_controller