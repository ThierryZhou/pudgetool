#pragma once

#include <memory>
#include <mutex>
#include "ICareAlgDefine.h"
#include "IcareAlgDecoder.hpp"
#include "ICareAlgSnapshotBase.hpp"

namespace alg_controller{
    
/**
 * @Brief 视频通道类
 * @Detail 每接入一个视频就创建一个对应的视频通道类对象与之对应，
 *  一个对象包含一个解码器对象和一个转发算法实例对象
 */

template<typename TSnap>
class CICareAlgChannel
{
public:
    CICareAlgChannel() {};

    virtual ~CICareAlgChannel() {};

public:
    int init(int height, int width, int image_fmt, int nDeviceIdx, int nChanIndex, std::thread&& newRunThead)
    {
        m_nHeight = height;
        m_nWidth = width;
        m_nImageFmt = image_fmt;

        // DeviceContext* pContext = ptrDevInfo->m_pStruContext;
        this->ptrDecoder = newDecoder(height, width, image_fmt, nDeviceIdx);
        if ( !this->ptrDecoder )
        {
            // LOG(ERROR) << "gpu device doesn't have enough resource to decode video.";
            return -1;
        }

        this->ptrAlgInstance = newAlgInstance(height, width, image_fmt, nDeviceIdx, nChanIndex);
        if ( !this->ptrAlgInstance )
        {
            // LOG(ERROR) << "gpu device doesn't have enough resource to decode video.";
            return -1;
        }

        this->m_nVideoChanIdx = nChanIndex;
        this->m_bRunning = true;

        // std::thread newRunThead(CICareAlgDevice::RunProc, pContext, nChanIndex);
        this->m_ptrChanThd = std::move(newRunThead);
  
        // LOG(INFO) << "CVFSChannel object init successful on GPU(" << ptrDevice->m_nDeviceIdx << ").";

        return 0;       
    };

    void uninit()
    {
        m_bRunning = false;

        if( ptrDecoder )
        {
            delDecoder(ptrDecoder);
        }

        if( ptrAlgInstance )
        {
            delAlgInstatnce(ptrAlgInstance);
        }

        // LOG(INFO) << "CVFSChannel object uninit successful.";
    };

    std::shared_ptr<CICareAlgDecoder> newDecoder(int height, int width, int image_fmt, int deviceIdx)
    {
        std::shared_ptr<CICareAlgDecoder> ptrDecoder = std::make_shared<CICareAlgDecoder>();
        ptrDecoder->init(height, width, deviceIdx);
        return ptrDecoder;
    };

    void delDecoder(std::shared_ptr<CICareAlgDecoder> pDecoder)
    {
        pDecoder->uninit();
    };


    std::shared_ptr<CICareAlgSnapshotBase> newAlgInstance(int height, int width, int image_fmt, int deviceIdx, int nChannel)
    {
        std::shared_ptr<CICareAlgSnapshotBase> pFaceAlg = std::make_shared<TSnap>();
        pFaceAlg->init(height, width, image_fmt, nChannel);
        return pFaceAlg;
    };

    void delAlgInstatnce(std::shared_ptr<CICareAlgSnapshotBase> pFaceAlg)
    {
        pFaceAlg->uninit();
    };

public:
    int     m_nVideoChanIdx = 0;
    int     m_nHeight = 0;
    int     m_nWidth = 0;
    int     m_nImageFmt = 0;
    bool    m_bRunning = false;
    // bool    bInit = false;
    // bool    bDataReady = false;
    // std::string strModelPath = "";
    // std::string strDeviceName = "";

    std::shared_ptr<CICareAlgDecoder> ptrDecoder;
    std::shared_ptr<CICareAlgSnapshotBase> ptrAlgInstance;

    VFAPacket* pOutPack = nullptr;

public:
    std::thread m_ptrChanThd;
    std::mutex m_mutRunProc;
    std::condition_variable m_cvRunProc;
    bool m_bRunProc = false;

    std::mutex m_mutOutProc;
    std::condition_variable m_cvOutProc;
    bool m_bOutProc = false;

    void NotifyRunProc()
    {
        std::unique_lock<std::mutex> procRunLock(m_mutRunProc);
        m_bRunProc = true;
        m_cvRunProc.notify_all();
    };

    void WaitRunProc()
    {
        std::unique_lock<std::mutex> procRunLock(m_mutRunProc);
        while( !m_bRunProc ){
            m_cvRunProc.wait(procRunLock);
        }
        m_bRunProc = false;
    };

    void NotifyPopPack()
    {
        std::unique_lock<std::mutex> procOutLock(m_mutOutProc);
        m_bOutProc = true;
        m_cvOutProc.notify_all();
    };

    void WaitPopPack(int nSemaphore)
    {
        std::unique_lock<std::mutex> procOutLock(m_mutOutProc);
        while( !(m_bOutProc == nSemaphore)){
            m_cvOutProc.wait(procOutLock);
        }
        m_bOutProc = false;
    };

    static int RunProc(std::shared_ptr<CICareAlgChannel<TSnap>> ptrChannel, int nDeviceIdx, int nChannel)
    {
        // LOG(INFO) << "got m_mutInit Lock in RunProc thread. channel:" << nChannel;

        unsigned long* pMask;
        unsigned int nMask;

        GetGpuAffinity(nDeviceIdx, &pMask, &nMask);
        if( nMask != 0 )
        {
            setCpuAffinity(pMask, nMask);
            delete pMask;
            pMask = nullptr;
        }
        else
        {
            // LOG(ERROR) << "set Cpu Affinity is failed.";
            return -1;
        }
        
        bindGPUDvice(nDeviceIdx);

        LOG(INFO) << "bindGPU Device:" << nDeviceIdx << ", channel:" << nChannel;

        while ( ptrChannel->m_bRunning )
        {
            ptrChannel->WaitRunProc();

            std::shared_ptr<CICareAlgDecoder> ptrDecoder = ptrChannel->ptrDecoder;
            std::shared_ptr<CICareAlgSnapshotBase> ptrAlgInstance = ptrChannel->ptrAlgInstance;

            VFSFrame* srcFrame = nullptr;
            srcFrame = ptrDecoder->PopFrame();
            if( !srcFrame )
            {
                // LOG(WARNING) << "Pop no data.";
                ptrChannel->NotifyPopPack();
                ptrChannel->pOutPack = nullptr;
                continue;
            }
            
            VFAPacket*    pVPack = nullptr;
            int ret = ptrAlgInstance->AlgProcess(srcFrame, &pVPack);
            if( ret < 0)
            {
                LOG(ERROR) << "call Alg module return:" << ret;
                continue;
            }

            ptrChannel->NotifyPopPack();

            ptrChannel->pOutPack = pVPack;
            // LOG(INFO) << "notify m_mutOutProc mutex.";

        }

        return 1;
    };

};

}; //namespace alg_controller