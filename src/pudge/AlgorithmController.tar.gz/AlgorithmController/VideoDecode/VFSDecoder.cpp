#include "VFSDecoder.hpp"
#include "NvDecoder.hpp"
extern "C"{
#include "jssjBasicFunction.h"
}
#include <cuda.h>
#include <glog/logging.h>
#include <chrono>
#include <memory>
#include <map>
#include <fstream>

bool CVFSDecoder::m_bIsRunning = true;

CVFSDecoder::CVFSDecoder()
{
}

CVFSDecoder::CVFSDecoder(std::shared_ptr<NvDecoder> ptrDec)
{
    m_ptrDecode = ptrDec;
};

CVFSDecoder& CVFSDecoder::operator=(CVFSDecoder&& other)
{
    m_thd = std::move(other.m_thd);
    return *this;
}

CVFSDecoder::~CVFSDecoder()
{
    join();
}

void CVFSDecoder::join()
{
    if (m_thd.joinable())
    {
        m_thd.join();
    }
}

int CVFSDecoder::startThread()
{
    if ( false == CVFSDecoder::m_bIsRunning )
    {
        CVFSDecoder::m_bIsRunning = true;
    }

    std::thread newThread(CVFSDecoder::DecProc, this);
    m_thd = std::move(newThread);
    
    return 0;
}

int CVFSDecoder::stopThread()
{
    CVFSDecoder::m_bIsRunning = false;
    return 0;
}

int CVFSDecoder::init(int nHeight, int nWidth, int iGpu)
{
    CUdevice cuDevice = 0;
    ck(cuDeviceGet(&cuDevice, iGpu));
    char szDeviceName[80];
    ck(cuDeviceGetName(szDeviceName, sizeof(szDeviceName), cuDevice));
    CUcontext cuContext = NULL;
    ck(cuCtxCreate(&cuContext, 0, cuDevice));

    if (!m_ptrDecode)
    {            
        m_nMaxHeight = nHeight;
        m_nMaxWidth = nWidth;
        m_nDeviceId = iGpu;
        m_cuContext = cuContext;

        JSDJ_BF_InitParam init_param;
        init_param.max_buffer_size = m_nMaxWidth * m_nMaxHeight * 3;

        // JSSJ_BF_SetGpuDevice(0, iGpu);
        JSSJ_BF_Init(&init_param, &m_bfHandle);

        m_ptrDecode = std::make_shared<NvDecoder>(cuContext, nWidth, nHeight, true, VFS2NvCodecId(H264));

        m_postDecFrame = AllocVFSFrame(m_nMaxHeight, m_nMaxWidth, m_nMaxHeight * m_nMaxWidth * 3 / 2, NV12, false);

        m_pDecodedFrame = newBFImage(m_nMaxHeight, m_nMaxWidth, BF_IMG_YUV420_NV12);
        m_pTempFrame = newBFImage(m_nMaxHeight, m_nMaxWidth, BF_IMG_BGR);

        startThread();
    }
    return 0;

};

void CVFSDecoder::uninit()
{
    if ( m_pDecodedFrame )
    {
        FreeVFSFrame(&m_postDecFrame);
    }

    delBFImage(m_pDecodedFrame);
    m_pDecodedFrame = nullptr;

    delBFImage(m_pTempFrame);
    m_pTempFrame = nullptr;

    
    ck(cuCtxDestroy(m_cuContext));
};

void CVFSDecoder::DecProc(CVFSDecoder* ptrThis)
{
    if (!ptrThis)
    {
        return;
    }

    bindGPUDvice(ptrThis->m_nDeviceId);

    int nFrame = 0;
    while (m_bIsRunning)
    {
        int nVideoBytes = 0, nFrameReturned = 0;
        uint8_t *pVideo = NULL, **ppFrame = NULL;

        try
        {
            ptrThis->WaitPushData();

            std::shared_ptr<NvDecoder> ptrDec = ptrThis->m_ptrDecode;
            VFSFrame* preDecodeFrame = ptrThis->m_preDecFrame;
            if ( !preDecodeFrame )
            {
                LOG(ERROR) << "can't find preDecode frame!";
                ptrThis->SignalPopDec();
                continue;
            }

            pVideo = GetVFSFrameData(preDecodeFrame);
            nVideoBytes = preDecodeFrame->len;
            int bDec = ptrDec->Decode(pVideo, nVideoBytes, &ppFrame, &nFrameReturned);
            if( bDec <= 0 )
            {
                LOG(WARNING) << "Decode function return 0";
            }
            nFrame += nFrameReturned;

            if ( 0 == nFrameReturned )
            {
                // LOG(WARNING) << "decode with no datas output! Frame Index:" << nFrame;
                ptrThis->SignalPopDec();
                continue;
            }

            JSDJ_BF_Image orgImage;
            orgImage.width = ptrThis->m_nMaxWidth;
            orgImage.height = ptrThis->m_nMaxHeight;
            orgImage.batch = 1;
            orgImage.data_size = ptrThis->m_nMaxHeight * ptrThis->m_nMaxWidth * 3 / 2;
            orgImage.image_format = BF_IMG_YUV420_NV12;
            orgImage.memory_size = ptrThis->m_nMaxHeight * ptrThis->m_nMaxWidth * 3 / 2;
            orgImage.storage_format = BF_GPU_DEVICE;
            orgImage.image_data = ppFrame[0];
            // JSDJ_BF_Image* pBGRFrame = ptrThis->newBFImage(ptrThis->m_nMaxWidth, ptrThis->m_nMaxHeight, BF_IMG_BGR);
            //JSDJ_BF_Image* pBGRFrame = ptrThis->m_pTempFrame;
            //ptrThis->conver2BGR(&orgImage, pBGRFrame);

            CopyImage2VFSFrame(&orgImage, ptrThis->m_postDecFrame);
            
            ptrThis->m_bDataReady = true;
            ptrThis->SignalPopDec();

            // LOG(INFO) << "decode data is ready for pulling.\r\n";
        }
        catch (std::exception& ex)
        {
            LOG(ERROR) << "Video Decode caught an error:" << ex.what();
        }
    }
}

int CVFSDecoder::PushAndNodify(VFSFrame* srcFrame)
{
    // LOG(INFO) << "PushAndNodify Decode start";
    std::unique_lock<std::mutex> pushLock(m_mutPushData);
    int nFrame = m_nFrameIdx++;
    m_preDecFrame = srcFrame;
    m_bPushData = true;
    m_cvPushData.notify_all();
    // LOG(INFO) << "PushAndNodify Decode end";
    return nFrame;
}

void CVFSDecoder::WaitPushData()
{
    std::unique_lock<std::mutex> pushLock(m_mutPushData);
    while( !m_bPushData ){
        m_cvPushData.wait(pushLock);
    }
    m_bPushData = false;
}

VFSFrame* CVFSDecoder::PopFrame()
{
    WaitPopDec();
    if( !m_postDecFrame || !m_bDataReady )
    {
        return nullptr;
    }
    m_bDataReady = false;
    VFSFrame* popFrame = m_postDecFrame;
    return popFrame;
}    


JSDJ_BF_Image* CVFSDecoder::newBFImage(int nHeight, int nWidth, JSDJ_BF_ImageFormat imgFormat)
{
    JSDJ_BF_Image* pBFImage = (JSDJ_BF_Image*)malloc(sizeof(JSDJ_BF_Image));
    if( !pBFImage )
    {
        return nullptr;
    }

    pBFImage->width = nWidth;
    pBFImage->height = nHeight;
    pBFImage->batch = 1;
    pBFImage->data_size = nWidth * nHeight * 3;
    pBFImage->image_format = imgFormat;
    pBFImage->memory_size = nWidth * nHeight * 3;
    pBFImage->storage_format = BF_GPU_DEVICE;
    int ret = JSSJ_BF_InitImg(pBFImage);
    if( ret < 0 )
    {
        return nullptr;
    }

    return pBFImage;
}

void CVFSDecoder::delBFImage(JSDJ_BF_Image* pBFImg)
{
    JSSJ_BF_ReleaseImg(pBFImg);
    free(pBFImg);
    pBFImg = NULL;
}

int CVFSDecoder::conver2BGR(JSDJ_BF_Image* pOrg, JSDJ_BF_Image* pDest)
{
    int ret = JSSJ_BF_FormatConv(m_bfHandle, BF_GPU_DEVICE, pOrg, 1, pDest);
    if ( ret ) 
    {
        // JSSJ_BF_GetLastErrorString(m_bfHandle, ret, error_string, 128);
        return -1;
    }  

    return 0;
}

void CVFSDecoder::SignalPopDec()
{
    // LOG(INFO) << "SignalPop start";
    std::unique_lock<std::mutex> popLock(m_mutPopData);
    ++m_nPopCount;
    m_cvPopData.notify_all();
    // LOG(INFO) << "SignalPop end " << m_nPopCount;
}

void CVFSDecoder::WaitPopDec()
{
    // LOG(INFO) << "WaitPop start";
    std::unique_lock<std::mutex> popLock(m_mutPopData);
    while( 0 == m_nPopCount )
    {
        m_cvPopData.wait(popLock);
    }
    --m_nPopCount;
    // LOG(INFO) << "WaitPop end " << m_nPopCount;
}
