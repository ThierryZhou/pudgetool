﻿#ifdef TEST_UNIT

#include <nvml.h>
#include <sched.h> 
#include <thread>
#include <memory>
#include <mutex>
#include <future>

#if 0
#define MAX_STREAM 1
#define CAPS "video/x-h264"

typedef struct myDataTag {
    GstElement *pipeline;
    GstElement *rtspsrc;
    GstElement *depay;
    GstElement *parse;
    GstElement *decode;
    GstElement *sink;
} myData_t;

typedef struct pair_frame {
    int nChan;
    VFSCodec* pCodec;
}pair_frame;

static int onDataCB(int nChan, int nFrameIdx, unsigned char* pData, int nLen)
{
    printf("onDataCB(chan:%d, len:%d)!\r\n", nChan, nLen);
    return 0;
};

GstFlowReturn new_sample(GstElement *sink, gpointer *data)
{
    GstSample *sample = gst_app_sink_pull_sample(GST_APP_SINK(sink));
    
    if (sample != NULL) 
    {
        //const GstStructure *strc = gst_sample_get_info(sample);
        //int height, width;
        //if (!gst_structure_get_int(strc, "width", &width) ||
        //    !gst_structure_get_int(strc, "height", &height))
        //{
        //    g_print("No width/height available\n");
        //    return GST_FLOW_OK;
        //}

        GstBuffer *buffer = gst_sample_get_buffer(sample);
        GstMapInfo map;
        if (buffer != NULL) 
        {
            struct pair_frame* pf = (struct pair_frame*)data;
            gst_buffer_map(buffer, &map, GST_MAP_READ);
            
            VFSFrame* pFrame = vfs_codec_new_frame(map.data, map.size);
            vfs_codec_decode_video(pf->pCodec, pf->nChan, pFrame);
            //vfs_codec_free_frame(pFrame);

            gst_buffer_unmap(buffer, &map);
            gst_sample_unref(sample);

        }
    }

    return GST_FLOW_OK;
};

int rtsp_decode(struct pair_frame* pf)
{
    GError *error = NULL;
    GMainLoop *loop = NULL;
    GstPad *sinkpad = NULL, *srcpad = NULL;
    myDataTag dataTag;;
    myData_t* appData = &dataTag;

    loop = g_main_loop_new(NULL, FALSE);

    //appData->pipeline = gst_pipeline_new("rtspclient");

    gchar *strPip = g_strdup_printf("rtspsrc location=%s ! rtph264depay ! h264parse ! appsink name=asink", "rtsp://172.16.4.27:8554/new-2.264");

    appData->pipeline = gst_parse_launch(strPip, &error);
    if (!appData->pipeline) {
        g_print("gst_parse_launch error: %s\n", error->message);
        exit(1);
    }

    gint width, height;
    GstSample *sample;
    gint64 duration, position;
    GstStateChangeReturn ret;
    gboolean res;
    GstMapInfo map;

    /* get sink */
    appData->sink = gst_bin_get_by_name(GST_BIN(appData->pipeline), "asink");
    if (!appData->pipeline) {
        g_print("gst_bin_get_by_name error: %s\n", error->message);
        exit(1);
    }

    gst_app_sink_set_emit_signals(GST_APP_SINK(appData->sink), TRUE);
    g_signal_connect(appData->sink, "new-sample", G_CALLBACK(new_sample), pf);

    ret = gst_element_set_state(appData->pipeline, GST_STATE_PLAYING);

    g_print("Running...\n");
    g_main_loop_run(loop);

    g_print("Returned, stopping playback\n");
    gst_element_set_state(appData->pipeline, GST_STATE_NULL);

    g_print("Deleting pipeline\n");
    gst_object_unref(GST_OBJECT(appData->pipeline));
    g_main_loop_unref(loop);

    //vfs_codec_destory(pCodec);
    //vfs_codec_uninit();
};

//int setCpuAffinity(unsigned long* lMask)
//{
//    cpu_set_t mask;
//    cpu_set_t mask0;
//    cpu_set_t mask1;
//    CPU_ZERO(&mask);
//    CPU_ZERO(&mask0);
//    CPU_ZERO(&mask1);
//
//    // 根据上边获取的亲和性数据设置cpu
//    for (int k = 0; k < iCpuNum; ++k)
//    {
//        if (1 == szCpuSetResult[0][k])
//        {
//            CPU_SET(k, &mask0);
//        }
//        else
//        {
//            CPU_SET(k, &mask1);
//        }
//    }
//
//    // 根据当前线程在哪个GPU上跑，决定绑定到哪些CPU核
//    if (szCpuSetResult[cur_gpu_id][0] == szCpuSetResult[0][0])
//        mask = mask0;
//    else
//        mask = mask1;
//
//    if (sched_setaffinity(0, sizeof(mask), &mask) == -1)
//    {
//        printf("set CPU affinity error!\n");
//    }
//
//    return 0;
//}

int main(int argc, char* argv[])
{
    unsigned long* pMask;
    unsigned int nMask;
    GetGpuAffinity(0, &pMask, &nMask);
    setCpuAffinity(pMask, nMask);

    VFSCodec* g_codec[MAX_STREAM] = { 0 };

    gst_init(&argc, &argv);
    vfs_codec_init();
    
    std::future<int> fut[MAX_STREAM];
    for (int i = 0; i < MAX_STREAM; i++)
    {
        int idx = i / 2;
        struct pair_frame* pf = (struct pair_frame*)malloc(sizeof(struct pair_frame));
        if (!g_codec[idx])
        {
            g_codec[idx] = vfs_create_decoder(VFSCodecID::H264);

            vfs_codec_setparam(g_codec[idx], 0, i % 2, 1080, 1920);
            int nRet = vfs_codec_open(g_codec[idx]);
            int nChan = vfs_codec_addChan(g_codec[idx], onDataCB);
            
            pf->nChan = nChan;
            pf->pCodec = g_codec[idx];
        }

        fut[i] = std::async(rtsp_decode, pf);
    }
};

//
//typedef struct _CustomData {
//    GstElement *pipeline, *app_source, *tee, *audio_queue, *audio_convert1, *audio_resample, *audio_sink;
//    GstElement *video_queue, *audio_convert2, *visual, *video_convert, *video_sink;
//    GstElement *app_queue, *app_sink;
//
//    guint64 num_samples;   /* Number of samples generated so far (for timestamp generation) */
//    gfloat a, b, c, d;     /* For waveform generation */
//
//    guint sourceid;        /* To control the GSource */
//
//    GMainLoop *main_loop;  /* GLib's Main Loop */
//} CustomData;
//

//static GstPadProbeReturn
//pad_probe_cb(GstPad * pad, GstPadProbeInfo * info, gpointer user_data)
//{
//    GstPad *srcpad, *sinkpad;
//
//    GST_DEBUG_OBJECT(pad, "pad is blocked now");
//
//    /* remove the probe first */
//    gst_pad_remove_probe(pad, GST_PAD_PROBE_INFO_ID(info));
//
//    /* install new probe for EOS */
//    srcpad = gst_element_get_static_pad(cur_effect, "src");
//    gst_pad_add_probe(srcpad, GST_PAD_PROBE_TYPE_BLOCK |
//        GST_PAD_PROBE_TYPE_EVENT_DOWNSTREAM, event_probe_cb, user_data, NULL);
//    gst_object_unref(srcpad);
//
//    /* push EOS into the element, the probe will be fired when the
//     * EOS leaves the effect and it has thus drained all of its data */
//    sinkpad = gst_element_get_static_pad(cur_effect, "sink");
//    gst_pad_send_event(sinkpad, gst_event_new_eos());
//    gst_object_unref(sinkpad);
//
//    return GST_PAD_PROBE_OK;
//}
//
//static gboolean
//timeout_cb(gpointer user_data)
//{
//    gst_pad_add_probe(blockpad, GST_PAD_PROBE_TYPE_BLOCK_DOWNSTREAM,
//        pad_probe_cb, user_data, NULL);
//
//    return TRUE;
//}

//static gboolean
//bus_cb(GstBus * bus, GstMessage * msg, gpointer user_data)
//{
//    GMainLoop *loop = user_data;
//
//    switch (GST_MESSAGE_TYPE(msg)) {
//    case GST_MESSAGE_ERROR: {
//        GError *err = NULL;
//        gchar *dbg;
//
//        gst_message_parse_error(msg, &err, &dbg);
//        gst_object_default_error(msg->src, err, dbg);
//        g_clear_error(&err);
//        g_free(dbg);
//        g_main_loop_quit(loop);
//        break;
//    }
//    default:
//        break;
//    }
//    return TRUE;
//}
//
//static GstPadProbeReturn h264_buffer_probe(GstPad * pad, GstPadProbeInfo * probe_info, gpointer u_data)
//{
//    //GstBuffer *gstbuf = (GstBuffer *)probe_info->data;
//    gint len;
//    GstMapInfo map;
//    guint16 *ptr, t;
//    GstBuffer *buffer;
//
//    buffer = GST_PAD_PROBE_INFO_BUFFER(probe_info);
//
//    buffer = gst_buffer_make_writable(buffer);
//
//    /* Making a buffer writable can fail (for example if it
//     * cannot be copied and is used more than once)
//     */
//    if (buffer == NULL)
//        return GST_PAD_PROBE_OK;
//
//    /* Mapping a buffer can fail (non-writable) */
//    if (gst_buffer_map(buffer, &map, GST_MAP_WRITE))
//    {
//        ptr = (guint16 *)map.data;
//        len = map.size;
//
//        VideoDecode((uint8_t*)ptr, (int)len);
//
//        gst_buffer_unmap(buffer, &map);
//    }
//
//    GST_PAD_PROBE_INFO_DATA(probe_info) = buffer;
//
//    return GST_PAD_PROBE_OK;
//};
//


//static GstElement *create_h264_bin(guint index, gchar * uri)
//{
//    CustomData *pcData;
//    GstElement *bin = NULL;
//    GstElement *sink = NULL, *appsink = NULL;
//    GstElement *rtsp_src = NULL, *rtp_h264_depay = NULL, *h264_parse = NULL;
//    gchar bin_name[16] = { };
//
//    g_snprintf(bin_name, 15, "source-bin-%02d", index);
//    /* Create a source GstBin to abstract this bin's content from the rest of the
//     * pipeline */
//    bin = gst_bin_new(bin_name);
//
//    /* Source element for reading from the uri.
//     * We will use decodebin and let it figure out the container format of the
//     * stream and the codec and plug the appropriate demux and decode plugins. */
//    rtsp_src = gst_element_factory_make("rtspsrc", "rtsp-src");
//    rtp_h264_depay = gst_element_factory_make("rtph264depay", "rtp-h264-depay");
//    h264_parse = gst_element_factory_make("h264parse", "h264-parse");
//
//    if (!bin || !rtsp_src) {
//        g_printerr("One element in source bin could not be created.\n");
//        return NULL;
//    }
//
//    appsink = gst_element_factory_make("appsink", "app-sink");
//
//    g_signal_connect(appsink, "new-sample", G_CALLBACK(onData), &pcData);
//
//    gulong id;
//    GstPad *sinkpad, *srcpad;
//    gchar pad_name[16] = { };
//
//    gst_bin_add_many(GST_BIN(bin), rtsp_src, rtp_h264_depay, h264_parse, appsink, NULL, NULL);
//    gst_element_link_many(rtsp_src, rtp_h264_depay, h264_parse, appsink, NULL, NULL);
//
//    /* We set the input uri to the source element */
//    g_object_set(G_OBJECT(rtsp_src), "location", uri, NULL);
//
//    /* We need to create a ghost pad for the source bin which will act as a proxy
//     * for the video decoder src pad. The ghost pad will not have a target right
//     * now. Once the decode bin creates the video decoder and generates the
//     * cb_newpad callback, we will set the ghost pad target to the video decoder
//     * src pad. */
//    if (!gst_element_add_pad(bin, gst_ghost_pad_new_no_target("src", GST_PAD_SRC))) {
//        g_printerr("Failed to add ghost pad in source bin\n");
//        return NULL;
//    }
//
//    return bin;
//};
//
//int main(int argc, char* argv[])
//{
//    GMainLoop *loop = NULL;
//    GstElement *pipeline = NULL, *source_bin = NULL;
//    GstBus *bus = NULL;
//    guint bus_watch_id;
//    GstPad *video_probe_id = NULL;
//    guint i, num_sources;
//
//    /* Check input arguments */
//    if (argc < 2) {
//        g_printerr("Usage: %s <uri1> [uri2] ... [uriN] \n", argv[0]);
//        return -1;
//    }
//    num_sources = argc - 1;
//
//    /* Standard GStreamer initialization */
//    gst_init(&argc, &argv);
//    loop = g_main_loop_new(NULL, FALSE);
//
//    /* Create gstreamer elements */
//    /* Create Pipeline element that will form a connection of other elements */
//    pipeline = gst_pipeline_new("deocde-pipeline");
//    if (!pipeline) {
//        g_printerr("One element could not be created. Exiting.\n");
//        return -1;
//    }
//
//    //gst_bin_add(GST_BIN(pipeline), sink);    
//
//    for (i = 0; i < num_sources; i++) 
//    {
//        CustomData *pcData;
//        GstElement *bin = NULL;
//        GstElement *sink = NULL, *appsink = NULL;
//        GstElement *rtsp_src = NULL, *rtp_h264_depay = NULL, *h264_parse = NULL;
//        GstElement *faksink;
//        gchar bin_name[16] = { };
//
//        /* Source element for reading from the uri.
//         * We will use decodebin and let it figure out the container format of the
//         * stream and the codec and plug the appropriate demux and decode plugins. */
//        rtsp_src = gst_element_factory_make("rtspsrc", "src");
//        
//        /* We set the input uri to the source element */
//        
//        g_object_set(G_OBJECT(rtsp_src), "location", "rtsp://172.16.4.27:8554/new-2.264", NULL);
//        g_object_set(G_OBJECT(rtsp_src), "latency", 0, NULL);
//
//        faksink = gst_element_factory_make("fakesink", "fake");
//
//        //rtp_h264_depay = gst_element_factory_make("rtph264depay", "rtp-h264-depay");
//        //h264_parse = gst_element_factory_make("h264parse", "h264-parse");
//
//        appsink = gst_element_factory_make("appsink", "app-sink");
//
//        g_signal_connect(appsink, "new-sample", G_CALLBACK(onData), &pcData);
//
//        //gst_bin_add_many(GST_BIN(pipeline), rtsp_src, rtp_h264_depay, h264_parse, appsink, NULL, NULL);
//        //gst_element_link_many(rtsp_src, rtp_h264_depay, h264_parse, appsink, NULL, NULL);
//        gst_bin_add_many(GST_BIN(pipeline), rtsp_src, faksink, NULL, NULL);
//        gst_element_link_many(rtsp_src, faksink, NULL, NULL);
//
//    }
//
//    /* we add a message handler */
//    bus = gst_pipeline_get_bus(GST_PIPELINE(pipeline));
//    bus_watch_id = gst_bus_add_watch(bus, bus_call, loop);
//    gst_object_unref(bus);
//
//    /* Set up the pipeline */
//    /* we add all elements into the pipeline */
//    //gst_bin_add(GST_BIN(pipeline), sink);
//
//    /* we link the elements together
//     * nvstreammux -> nvinfer -> nvtiler -> nvvidconv -> nvosd -> video-renderer */
//    //if (!gst_element_link_many(streammux, sink, NULL)) {
//    //    g_printerr("Elements could not be linked. Exiting.\n");
//    //    return -1;
//    //}
//
//    /* Set the pipeline to "playing" state */
//    g_print("Now playing:");
//    for (i = 0; i < num_sources; i++)
//    {
//        g_print(" %s,", argv[i + 1]);
//    }
//    g_print("\n");
//    gst_element_set_state(pipeline, GST_STATE_PLAYING);
//
//    /* Wait till pipeline encounters an error or EOS */
//    g_print("Running...\n");
//    g_main_loop_run(loop);
//
//    /* Out of the main loop, clean up nicely */
//    g_print("Returned, stopping playback\n");
//    gst_element_set_state(pipeline, GST_STATE_NULL);
//    g_print("Deleting pipeline\n");
//    gst_object_unref(GST_OBJECT(pipeline));
//    g_source_remove(bus_watch_id);
//    g_main_loop_unref(loop);
//
//    return 0;
//}

#endif 

#if 0
extern "C"{
#include <gst/gst.h>
#include <gst/gstpad.h>
#include <glib.h>
#include <gst/app/app.h>
}

static gboolean
bus_call(GstBus *bus, GstMessage *msg, gpointer data)
{

    GMainLoop *loop = (GMainLoop *)data;
    switch (GST_MESSAGE_TYPE(msg)) {

    case GST_MESSAGE_EOS:
        g_print("End of stream\n");
        g_main_loop_quit(loop);
        break;

    case GST_MESSAGE_ERROR: {
        gchar  *debug;
        GError *error;

        gst_message_parse_error(msg, &error, &debug);
        g_print("debug: %s\n", debug);
        g_free(debug);

        g_printerr("Error: %s\n", error->message);
        g_error_free(error);

        g_main_loop_quit(loop);
        break;
    }
    default:
        break;
    }

    return TRUE;
};

GstFlowReturn new_sample(GstElement *sink, gpointer *data) 
{
    g_print("new sample\n");
    GstSample *sample = gst_app_sink_pull_sample(GST_APP_SINK(sink));
    if (sample != NULL) {
        GstBuffer *buffer = gst_sample_get_buffer(sample);
        GstMapInfo map;
        if (buffer != NULL) {
            gst_buffer_map(buffer, &map, GST_MAP_READ);
            g_print("buffer size %zu\n", map.size);
            gst_buffer_unmap(buffer, &map);
            gst_sample_unref(sample);

        }
    }

    return GST_FLOW_OK;
};


void create_loop()
{
    GMainLoop *loop;

    GstElement *pipeline, *source, *buffer, *depay, *parse, *sink;
    GstBus *bus;
    guint bus_watch_id;

    loop = g_main_loop_new(NULL, FALSE);

    pipeline = gst_pipeline_new("video-player");
    source = gst_element_factory_make("rtspsrc", NULL);
    g_object_set(G_OBJECT(source), "location", "rtsp://172.16.4.27:8554/new-2.264", NULL);
    g_object_set(G_OBJECT(source), "latency", 0, NULL);
    g_object_set(G_OBJECT(source), "caps", "application/x-rtp,media=(string)video", NULL);
    
    buffer = gst_element_factory_make("rtpjitterbuffer", "buffer");
    depay = gst_element_factory_make("rtph264depay", "rtp-h264-depay");
    parse = gst_element_factory_make("h264parse", "h264-parse");
    sink = gst_element_factory_make("appsink", NULL);

    gst_app_sink_set_emit_signals(GST_APP_SINK(sink), TRUE);
    g_signal_connect(sink, "new-sample", G_CALLBACK(new_sample), NULL);

    if (!pipeline || !source || !sink) {
        g_printerr("One element could not be created. Exiting.\n");
        return;
    }

    //g_object_set(G_OBJECT(source), "device", "hw:3,0", NULL);

    bus = gst_pipeline_get_bus(GST_PIPELINE(pipeline));
    bus_watch_id = gst_bus_add_watch(bus, bus_call, loop);
    gst_object_unref(bus);

    gst_bin_add_many(GST_BIN(pipeline), source, buffer, depay, parse, sink, NULL);
    gst_element_link_many(source, buffer, depay, parse, sink, NULL);
    /*gst_bin_add_many(GST_BIN(pipeline), source, sink, NULL);
    gst_element_link_many(source, sink, NULL);
    */gst_element_set_state(pipeline, GST_STATE_PLAYING);

    g_print("Running...\n");
    g_main_loop_run(loop);

    g_print("Returned, stopping playback\n");
    gst_element_set_state(pipeline, GST_STATE_NULL);

    g_print("Deleting pipeline\n");
    gst_object_unref(GST_OBJECT(pipeline));
    g_source_remove(bus_watch_id);
    g_main_loop_unref(loop);

};

#endif

int main(int argc, char* argv[])
{
    return 0;
}
#endif
