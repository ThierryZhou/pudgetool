#pragma once

#include "VFSCodecDefine.h"
#include <deque>
#include <thread>
#include <memory>
#include <condition_variable>
#include <functional>
#include <vector>
#include <map>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#define MAX_DECODE_SHARED_CHANNELS    2

class NvDecoder;
struct JSDJ_BF_Image;

typedef int(*DecodeCallback)(int nChan, int nFrameIdx, unsigned char* pData, int nLen);

class CVFSDecoder
{
public:
    CVFSDecoder();

    CVFSDecoder(std::shared_ptr<NvDecoder> ptrDec);

    CVFSDecoder& operator=(CVFSDecoder&& other);

    virtual ~CVFSDecoder();

public:
    int init(int nHeight, int nWidth, int iGpu = 0);

    void uninit();

    void join();

    int startThread();

    int stopThread();

    bool hasFrameDecoded() { return !m_preDecFrame ? true : false; }
    
    static bool    m_bIsRunning;

public:

    static void DecProc(CVFSDecoder* ptrThd);

    int PushAndNodify(VFSFrame* srcFrame);

    void WaitPushData();

    VFSFrame* PopFrame();

    bool ifFirstFrame(){ return m_nFrameIdx == 0 ? true : false; };

private:

    JSDJ_BF_Image* newBFImage(int nHeight, int nWidth, JSDJ_BF_ImageFormat imgFormat);

    void delBFImage(JSDJ_BF_Image* pBFImg);

    int conver2BGR(JSDJ_BF_Image* pOrg, JSDJ_BF_Image* pDest);

private:
    std::thread             m_thd;
    unsigned int            m_nPopCount = 0;
    bool                    m_bPushData = false;
    std::condition_variable    m_cvPushData;
    std::condition_variable    m_cvPopData;
    std::mutex                 m_mutPushData;
    std::mutex                m_mutPopData;

public:
    void SignalPopDec();
    void WaitPopDec();

private:
    int                m_nDeviceId = 0;
    int                m_nFrameIdx = 0;
    int             m_nMaxHeight = 0;
    int             m_nMaxWidth = 0;
    volatile bool    m_bDataReady = false;
    void*            m_bfHandle = nullptr;
    VFSFrame*        m_preDecFrame = nullptr;
    VFSFrame*        m_postDecFrame = nullptr;
    JSDJ_BF_Image*    m_pDecodedFrame = nullptr;
    JSDJ_BF_Image*    m_pTempFrame = nullptr;
    CUcontext        m_cuContext = nullptr;

protected:
    // std::vector<std::vector<VFSFrame*>>        m_arrSrcFrames;
    // std::vector<std::vector<VFSFrame*>>        m_arrDestFrames;
    // std::map<int, VFSFrame*> m_mpSrcFrames;
    // std::map<int, VFSFrame*> m_mpDestFrames;
    // std::function<int(int, int, unsigned char*, int)> m_decodeCB;

    std::shared_ptr<VFSPacket>    m_destPacket = nullptr;
    std::shared_ptr<NvDecoder> m_ptrDecode = nullptr;
};