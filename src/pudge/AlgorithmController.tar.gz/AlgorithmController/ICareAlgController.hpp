/*****************************************************************
Copyright (C), 2018, iCare Vision Tech. Co., Ltd.
All rights reserved

FileName: ICareAlgController.hpp
Description: 抓拍算法调用类

History:
<author>        <time>        <version>        <Abstract>
 周辉          2018-12              1.0.0            创建此文件
*****************************************************************/
#pragma once

#include "SystemCall.h"
#include "ICareAlgDevice.hpp"
#include <memory>
#include <thread>
#include <deque>
#include <map>
#include <vector>
#include <mutex>
#include <condition_variable>

namespace alg_controller{

template<typename TSnap, typename TAly>
class CICareAlgDevice;

/**
 * @Brief 人脸抓拍算法调用类
 * @Detail 一个抓拍算法对象对应着多个视频通道，
 *         一个对象只对应一个算法调用实例。
 */
template<typename TSnap, typename TAly>
class CICareAlgController : public std::enable_shared_from_this<CICareAlgController<TSnap, TAly>>
{
public:
    CICareAlgController()
    {
        // google::InitGoogleLogging("ICareAlgController");
        // google::SetLogDestination(google::GLOG_INFO, "/home/zh/log/vfs_");
        // google::SetStderrLogging(google::INFO);
    };

    virtual ~CICareAlgController()
    {
        // google::ShutdownGoogleLogging();
    };

public:
    void init(int height, int width, int image_fmt, std::vector<int>& device_list, int max_channel, const char* pModel)
    {
        m_nMaxHeight = height;
        m_nMaxWidth = width;
        m_ImageFmt = image_fmt;
        m_nMaxChannel = max_channel;
        m_strModelPath = pModel;
        m_arrDeviceList.swap(device_list);
        intDevice();
    };

    void uninit()
    {
        unintDevice();
    }

    int intDevice()
    {
        ck(cuInit(0));
        
        int num = m_arrDeviceList.size();
        for(int i=0; i<num; ++i )
        {
            int in_use = m_arrDeviceList[i];
            if( 0 == in_use )
            {
                continue;
            }
            int nDevId = i;
            std::shared_ptr<CICareAlgDevice<TSnap,TAly>> ptrDevice = newICareAlgDevice(nDevId);
            m_mapICareAlgDevices.insert(std::make_pair(nDevId, ptrDevice));
        }
        return 0;
    }
        
    int unintDevice()
    {
        m_mapICareAlgDevices.clear();
        return 0;
    };

    std::shared_ptr<CICareAlgDevice<TSnap,TAly>> newICareAlgDevice(int nDeviceId)
    {
        std::shared_ptr<CICareAlgDevice<TSnap,TAly>> ptrDevice = std::make_shared<CICareAlgDevice<TSnap,TAly>>();
        ptrDevice->init(m_nMaxHeight, m_nMaxWidth, m_ImageFmt, nDeviceId, m_nMaxChannel, m_strModelPath.c_str());
        return ptrDevice;
    };

    int delICareAlgDevice(int nDeviceId)
    {
        // std::map<int, std::shared_ptr<CICareAlgDevice<TSnap,TAly>>>::iterator itor = m_mapICareAlgDevices.find(nDeviceId);
        auto itor = m_mapICareAlgDevices.find(nDeviceId);
        if( itor != m_mapICareAlgDevices.end() )
        {
            m_mapICareAlgDevices.erase(itor++);
            return 0;
        }

        return -1;
    };

    int newChannel(int height, int width, int image_fmt)
    {
        int nChanIdx;
        int num = m_arrDeviceList.size();
        for(int i=0; i<num; ++i )
        {
            std::shared_ptr<CICareAlgDevice<TSnap,TAly>> ptrDevice = m_mapICareAlgDevices[i];
            if( !ptrDevice || !ptrDevice->isFullLoad() )
            {
                nChanIdx = ptrDevice->newChannel(height, width, image_fmt);
                return nChanIdx +  m_nMaxChannel * ptrDevice->getDeviceIdx();
            }
        }

        return -1;
    };

    int delChannel(int nChannel)
    {
        int num = m_arrDeviceList.size();
        for(int i=0; i<num; ++i )
        {
            std::shared_ptr<CICareAlgDevice<TSnap,TAly>> ptrDevice = m_mapICareAlgDevices[i];
            if( !ptrDevice->isIdle() )
            {
                return ptrDevice->delChannel(nChannel);
            }
        }

        return -1;
    };

    int doProcess(int nChannel, const unsigned char* pData, unsigned int nLen, VFAPacket** outPacket)
    {
        int nDeviceId = nChannel / m_nMaxChannel;
        int nChannelIdx = nChannel % m_nMaxChannel;
        // std::map<int, std::shared_ptr<CICareAlgDevice<TSnap,TAly>>>::iterator itor = m_mapICareAlgDevices.find(nDeviceId);
        auto itor = m_mapICareAlgDevices.find(nDeviceId);
        if( itor != m_mapICareAlgDevices.end() )
        {
            // LOG(DEBUG) << "video channel:" << nChannel << ", do process for data.\r\n";
            std::shared_ptr<CICareAlgDevice<TSnap,TAly>> ptrDevice = itor->second;
            return ptrDevice->doProcess(nChannelIdx, pData, nLen, outPacket);
        }

        return -1;
    }

    int EndProcess(int nChannel, VFAPacket** outPacket)
    {
        int nDeviceId = nChannel / MAX_DEVICE_VIDEO_CHANNELS;
        int nChannelIdx = nChannel % MAX_DEVICE_VIDEO_CHANNELS;
        // std::map<int, std::shared_ptr<CICareAlgDevice<TSnap,TAly>>>::iterator itor = m_mapICareAlgDevices.find(nDeviceId);
        auto itor = m_mapICareAlgDevices.find(nDeviceId);
        if( itor != m_mapICareAlgDevices.end() )
        {
            // LOG(DEBUG) << "video channel:" << nChannel << ", do process for data.\r\n";
            std::shared_ptr<CICareAlgDevice<TSnap,TAly>> ptrDevice = itor->second;
            return ptrDevice->EndProcess(nChannelIdx, outPacket);
        }

        return 0;
    }

private:
    std::map<int, std::shared_ptr<CICareAlgDevice<TSnap,TAly>>>        m_mapICareAlgDevices;
    
public:
    int start();
    int stop();

private:
    static int RunProc(std::shared_ptr<CICareAlgController<TSnap,TAly>> ptrThis, int nChannel)
    {
        return 0;
    };

    bool m_bHasDecode = false;
    std::mutex      m_mutChannel;
    std::string     m_strModelPath = "";
    int m_ImageFmt;
    int m_nMaxHeight;
    int m_nMaxWidth;
     int m_nMaxChannel;
    std::vector<int> m_arrDeviceList;
};

}; //namespace alg_controller
